import styles from "./AppName.module.css";
function AppName() {
  return <h1 className="styles.todoHeading">Task Manager</h1>;
}
export default AppName;
